package Cat_Mouse_Gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingWorker;

public class CatMouseSimulation {

	
    public enum Status {
        Init, Running, Eaten, Stopped
    }
    
	private Cat cat;
	private Mouse mouse;
	
	private static Status status = Status.Init;
	private static int times = 0;

	/**
	 * Run the simulation
	 * @param cat
	 * @param mouse
	 */
//	public static void runChase(Cat cat, Mouse mouse) {
	public static void runChase(int numMin, Cat cat, Mouse mouse, MyDrawPanel drawPanel, JLabel countLabel) {
		int minutes = 0;
		/**
		 * Print initial states and nice headers.
		 * First line of terminal output.
		 */
		String headerString = String.format("%-4s %-8s  %-15s %-9s", "TIME", "STATUS", "MOUSE", "CAT");
		System.out.println(headerString);
		
		/**
		 * print initial state.
		 * Second line of terminal output.
		 */
		Position initPositionMouse = mouse.getPosition();
		Position initPositionCat = cat.getPosition();
		String initString = String.format("%-4d %-9s %-15s %-9s", minutes, "init", initPositionMouse.toString(), initPositionCat.toString());
		System.out.println(initString);
		
		
		/**
		 * run-catch starts.
		 */
		minutes++;
		String iterString = new String();
		
		while (minutes < 31) {
			//cat moves first, and determine whether catches the mouse during the move.
			boolean catEatsMouse = cat.move(mouse.getPosition());
			
			//if cat didn't eat mouse during its move.
			if (!catEatsMouse) {
				//mouse moves second.
				mouse.move();
				
				Position positionMouse = mouse.getPosition();
				Position positionCat = cat.getPosition();
				iterString = String.format("%-4d %-9s %-15s %-9s", minutes, "running", positionMouse.toString(), positionCat.toString());
				System.out.println(iterString);
				
			//if cat ate mouse during its move.
			} else if (catEatsMouse) {

				Position positionMouse = mouse.getPosition();
				Position positionCat = cat.getPosition();
				iterString = String.format("%-4d %-9s %-15s %-9s", minutes, "eaten", positionMouse.toString(), positionCat.toString());
				System.out.println(iterString);
				System.exit(1);
			}
			minutes++;
		}
		
		
		boolean catEatsMouse = cat.move(mouse.getPosition());
		
		//if cat caught the mouse at the 31th step (one more step than the limit).
		if (catEatsMouse) {
			iterString = String.format("%-4d %-9s", 31, "so close to caught, just need one more round... :(");
			System.out.println(iterString);
		} else {
			iterString = String.format("%-4d %-9s", 31, "far from catching the mouse... :(");
			System.out.println(iterString);
		}
	}

	
	
	/**
	 * Set up the arguments and then call runChase to run the simulation
	 * @param args
	 */
	public static void main(String[] args) {
		CatMouseSimulation simulation = new CatMouseSimulation();
		simulation.processArgs(args);
//		CatMouseSimulation.runChase(simulation.cat, simulation.mouse);
        CatMouseSimulation gui = new CatMouseSimulation();
        gui.go();
	}

	public Cat getCat() {
		return cat;
	}

	public Mouse getMouse() {
		return mouse;
	}

	private void processArgs(String[] args) {
		if (args.length != 3) {
			System.err.println("Usage:  java CatMouseSimulation catRadius catAngle mouseAngle");
			System.exit(1);
		}
		try {
			double catRad = Double.parseDouble(args[0]);
			double catAng = (Math.PI / 180) * (((Double.parseDouble(args[1])) % 360));
			Position p = new Position(catRad, catAng);
			cat = new Cat(p);// intializes cat
		} catch (Exception ex) {
			System.err.println("The first argument must specify a radius. The second argument must specify an angle.");
			System.exit(1);
		}
		try {
			double mouseRad = 1.0;
			double mouseAng = (Math.PI / 180) * (((Double.parseDouble(args[2])) % 360));
			Position p = new Position(mouseRad, mouseAng);
			mouse = new Mouse(p);// intializes mouse
		} catch (Exception ex) {
			System.err.println("The third argument must specify an angle.");
			System.exit(1);
		}
	}
	
	
    public void go() {
        // Frame
        JFrame frame = new JFrame("Cat and Mouse GUI");
 
        // Panel
        JPanel buttonPanel = new JPanel();
        MyDrawPanel drawPanel = new MyDrawPanel();
 
        // Buttons
        JButton reset = new JButton("reset");
        JButton step = new JButton("step");
        JButton run = new JButton("run");
        JButton quit = new JButton("quit");
 
        buttonPanel.add(reset);
        buttonPanel.add(step);
        buttonPanel.add(run);
        buttonPanel.add(quit);
 
        // Labels
        JLabel timeLabel = new JLabel("Time:");
        JLabel countLabel = new JLabel(" " + times);
 
        buttonPanel.add(timeLabel);
        buttonPanel.add(countLabel);
 
        // Listeners
        reset.addActionListener(new MyResetListener(drawPanel, countLabel));
        step.addActionListener(new MyStepListener(drawPanel, countLabel));
        run.addActionListener(new MyRunListener(drawPanel, countLabel));
        quit.addActionListener(new MyQuitListener(frame));
 
        // Draw UI
        frame.getContentPane().add(BorderLayout.SOUTH, buttonPanel);
        frame.getContentPane().add(BorderLayout.CENTER, drawPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 800);
        frame.setVisible(true);
    }
    
    private static void updateUI (JLabel countLabel, MyDrawPanel drawPanel) {
        drawPanel.onPaint();
        countLabel.setText("" + times + "Status:" + status);
        drawPanel.updateUI();
    }
 
    private class MyResetListener implements ActionListener {
        private final MyDrawPanel drawPanel;
        private final JLabel countLabel;
         
        public MyResetListener (final MyDrawPanel drawPanel, final JLabel countLabel) {
            this.drawPanel = drawPanel;
            this.countLabel = countLabel;
        }
        @Override
        public void actionPerformed(ActionEvent e) {
            // Reset position
            cat.setPosition(new Position (300.0, 0.0));
            mouse.setPosition(new Position (200.0, 0.0));
            times = 0;
            status = Status.Init;
             
            System.out.println("Reset: " + "       "
                    + mouse.getPosition().toString() + "    "
                    + cat.getPosition().toString());
             
            updateUI(countLabel, drawPanel);
 
        }
 
    }
 
    private class MyStepListener implements ActionListener {
        private final MyDrawPanel drawPanel;
        private final JLabel countLabel;
         
        public MyStepListener (MyDrawPanel drawPanel, JLabel countLabel) {
            this.drawPanel = drawPanel;
            this.countLabel = countLabel;
        }
 
        @Override
        public void actionPerformed(ActionEvent e) {
            if (status == Status.Init|| status == Status.Running) {
                 
                //
                 
                cat.move(mouse.getPosition());
                mouse.move();
                status = Status.Running;
                times ++;
                 
                // repaint UI
                updateUI(countLabel, drawPanel);
            }
        }
    }
 
    private class MyRunListener implements ActionListener {
        private final MyDrawPanel drawPanel;
        private final JLabel countLabel;
         
        public MyRunListener (MyDrawPanel drawPanel, JLabel countLabel) {
            this.drawPanel = drawPanel;
            this.countLabel = countLabel;
        }
 
        @Override
        public void actionPerformed(ActionEvent e) {
            SwingWorker<Object, Object> worker = new SwingWorker <Object, Object>() {
                 
                @Override
                protected Object doInBackground() throws Exception {
                    runChase(800, cat, mouse, drawPanel, countLabel);
                    return "Done";
                }      
            };
            worker.execute();
        }
    }
 
    private class MyQuitListener implements ActionListener {
        private final JFrame frame;
         
        public MyQuitListener (final JFrame frame) {
            this.frame = frame;
        }
     
        @Override
        public void actionPerformed(ActionEvent e) {
            frame.dispose();
        }
    }
    
    class MyDrawPanel extends JPanel {
        private static final long serialVersionUID = -1451876344365614067L;
        private Graphics g;
         
        public void onPaint() {
            paintComponent(g);
        }
         
        public void paintComponent(Graphics graphics) {
            g = graphics;
             
            g.setColor(Color.white);
            g.fillRect(0, 0, this.getWidth(), this.getHeight());
 
            g.setColor(Color.gray);
            g.fillOval(200, 200, 400, 400);
 
            g.setColor(Color.yellow); // cat is yellow color
            g.fillOval((int) (cat.getPosition().getMyRadius() * Math
                    .cos(cat.getPosition().getMyAngle())) + 400,
                    400 + (int) (cat.getPosition().getMyRadius() * Math
                            .sin(cat.getPosition().getMyAngle())), 10, 10);
 
            g.setColor(Color.blue); // mouse is blue color
            g.fillOval(400 + (int) (200 * Math.cos(mouse.getPosition()
                    .getMyAngle())), 400 + (int) (200 * Math.sin(mouse
                    .getPosition().getMyAngle())), 10, 10);
 
            g.setColor(Color.black);
            g.drawLine((int) (cat.getPosition().getMyRadius() * Math
                    .cos(cat.getPosition().getMyAngle())) + 400,
                    400 + (int) (cat.getPosition().getMyRadius() * Math
                            .sin(cat.getPosition().getMyAngle())),
                    400 + (int) (200 * Math.cos(mouse.getPosition()
                            .getMyAngle())), 400 + (int) (200 * Math
                            .sin(mouse.getPosition().getMyAngle())));
        }
    }
}