package Cat_Mouse_Gui;
import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;


public class MyDrawPanel extends JPanel {
    private static final long serialVersionUID = -1451876344365614067L;
    private Graphics g;
     
    public void onPaint() {
        paintComponent(g);
    }
     
    public void paintComponent(Graphics graphics) {
        g = graphics;
         
        g.setColor(Color.white);
        g.fillRect(0, 0, this.getWidth(), this.getHeight());

        g.setColor(Color.gray);
        g.fillOval(200, 200, 400, 400);
//        g.fillOval(200, 200, 100, 100);
        
        int catDis1 = (int) (CatMouseSimulation.getMyCat().getPosition().getMyRadius() * Math
                .cos(CatMouseSimulation.getMyCat().getPosition().getMyAngle())) + 400;
        int catDis2 = (int) (CatMouseSimulation.getMyCat().getPosition().getMyRadius() * Math
                .sin(CatMouseSimulation.getMyCat().getPosition().getMyAngle())) + 400;
        
        int mouseDis1 = (int) (200 * Math.cos(CatMouseSimulation.getMyMouse().getPosition()
                .getMyAngle())) + 400;
        int mouseDis2 = (int) (200 * Math.sin(CatMouseSimulation.getMyMouse()
                .getPosition().getMyAngle())) + 400;
        
        System.err.println("catDis1: " + catDis1 + " catDis2: " + catDis2);
        System.err.println("mouseDis1: " + mouseDis1 + " mouseDis2: " + mouseDis2);
        
        g.setColor(Color.yellow); // cat is yellow color
        g.fillOval(catDis1,
                catDis2, 10, 10);

        g.setColor(Color.blue); // mouse is blue color
        g.fillOval(mouseDis1, mouseDis2, 10, 10);

		g.setColor(Color.black);
		g.drawLine(catDis1, catDis2, mouseDis1, mouseDis2);
    }
}
