import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;


public class MyDrawPanel extends JPanel {
    private static final long serialVersionUID = -1451876344365614067L;
    private Graphics g;
     
    public void onPaint() {
        paintComponent(g);
    }
     
    public void paintComponent(Graphics graphics) {
        g = graphics;
         
        g.setColor(Color.white);
        g.fillRect(0, 0, this.getWidth(), this.getHeight());

        g.setColor(Color.gray);
        g.fillOval(200, 200, 400, 400);

        g.setColor(Color.yellow); // cat is yellow color
        g.fillOval((int) (CatMouseSimulation.getMyCat().getPosition().getMyRadius() * Math
                .cos(CatMouseSimulation.getMyCat().getPosition().getMyAngle())) + 400,
                400 + (int) (CatMouseSimulation.getMyCat().getPosition().getMyRadius() * Math
                        .sin(CatMouseSimulation.getMyCat().getPosition().getMyAngle())), 10, 10);

        g.setColor(Color.blue); // mouse is blue color
        g.fillOval(400 + (int) (200 * Math.cos(CatMouseSimulation.getMyMouse().getPosition()
                .getMyAngle())), 400 + (int) (200 * Math.sin(CatMouseSimulation.getMyMouse()
                .getPosition().getMyAngle())), 10, 10);

        g.setColor(Color.black);
        g.drawLine((int) (CatMouseSimulation.getMyCat().getPosition().getMyRadius() * Math
                .cos(CatMouseSimulation.getMyCat().getPosition().getMyAngle())) + 400,
                400 + (int) (CatMouseSimulation.getMyCat().getPosition().getMyRadius() * Math
                        .sin(CatMouseSimulation.getMyCat().getPosition().getMyAngle())),
                400 + (int) (200 * Math.cos(CatMouseSimulation.getMyMouse().getPosition()
                        .getMyAngle())), 400 + (int) (200 * Math
                        .sin(CatMouseSimulation.getMyMouse().getPosition().getMyAngle())));
    }
}
